# React + Vite + Tailwind + Airtable

Green Leadership Trust needs a simple portal to review duplicated records as well as a spam dectector
